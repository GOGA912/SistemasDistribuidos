package com.banco.sistemabancario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemabancarioApplicationTests {

	@Test
	void contextLoads() {
	}

}

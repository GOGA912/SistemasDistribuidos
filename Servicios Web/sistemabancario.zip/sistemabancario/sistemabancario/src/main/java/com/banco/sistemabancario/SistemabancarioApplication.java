package com.banco.sistemabancario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemabancarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemabancarioApplication.class, args);
	}

}
